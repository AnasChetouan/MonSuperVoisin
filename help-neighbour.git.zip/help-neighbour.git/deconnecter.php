


<?php
session_start();
/* @author : NOUARI heythem */
session_destroy();
header('location: '."home.php");
exit;
?>